const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'localhost',
    user: 'mahalak',
    password: 'mahalak',
    database: 'mahalak',
});

export default connection;